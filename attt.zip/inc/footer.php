<footer>
    <nav class="bg-light text-center p-3">
        <small>
            Phạm Cao Kỳ 2020
        </small>
    </nav>
</footer>
</body>

</html>