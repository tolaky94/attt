<div class="card">
    <div class="card-header bg-primary text-white">
        Các lỗi bảo mật hệ thống.
    </div>
    <div class="card-body">
        <h5 class="card-title"></h5>
        <div class="card-text">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Định nghĩa</a>
                </li>
            </ul>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <p>
                        - Các tài khoản webserver hoặc database để là mặc định hoặc quá dễ đoán.
                        <br>
                        - Đổi mật khẩu mặc định của hệ thống
                        <br>
                        - Nâng cấp phiên bản của nền tảng đang sử dụng tránh các lỗ hổng nghiêm trọng mà hacker có thể khai thác thông qua CVE.
                    </p>
                </div>
            </div>
        </div>
    </div>
    
</div>