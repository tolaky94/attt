<?php require_once(__DIR__.'/../inc/header.php'); ?>
<?php
    $name = isset($_GET['name']) ? $_GET['name'] : '';
    echo $name;
?>
<b>Nội dung ví dụ</b>
<script src="http://gist-it.appspot.com/https://github.com/tolaky94/attt/blob/master/demos/reflected.php"></script>
<?php require_once(__DIR__.'/../inc/footer.php'); ?>
